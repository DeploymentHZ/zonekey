# -*- coding:utf-8 -*-

class FileInfo(object):
    def __init__(self, uid, group_id, base_dir, source_dir, file_size=0, \
                 target_dir=None, vod_url=None):
        self.uid = uid
        self.group_id = group_id
        self.base_dir = base_dir
        self.source_dir = source_dir
        self.file_size = file_size
        self.target_dir = target_dir
        self.vod_url = vod_url
