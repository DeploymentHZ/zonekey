# -*- coding:utf-8 -*-

import os
import json
import torndb
from util.config import Config
from util.respcode import Resp, Code, RespCode
from service.basehandler import BaseHandler
from service.fileinfo import FileInfo

UPLOADING = 1
UPLOADED = 2
class VodRequestHandler(BaseHandler):
    def _post(self, params):
        tmpfile_list = []
        for sector in params:
            file = FileInfo(group_id = sector['group_id'],
                            uid = sector['uid'],
                            base_dir = sector['base_dir'],
                            source_dir = sector['file_name']
                            )
            if not os.path.isfile(os.path.join(file.base_dir, file.source_dir)):
                failure = "uid %s is not exist" % file.uid
                result = Resp.parse(code = RespCode.invalid_parameter, \
                                    failure = failure)
                return result
            file.file_size = os.path.getsize(os.path.join(file.base_dir, file.source_dir))
            tmpfile_list.append(file)
        uid_list = [x.uid for x in tmpfile_list]

        self.uploading_list = self.get_publish_list(uid_list, UPLOADING)
        self.uploaded_list = self.get_publish_list(uid_list, UPLOADED)
        dbupload_count = self.get_upload_list()
        left_upload = int(self.config.filesystem.max_upload_list) \
                      + len(self.uploading_list) \
                      + len(self.uploaded_list) \
                      - int(dbupload_count)

        if (len(tmpfile_list) > left_upload):
            failure = "current upload list has %d capacity, \
                        cut your upload request" % left_upload
            result = Resp.parse(code = RespCode.invalid_parameter, \
                                failure = failure)
            return result

        self.update_file_list(tmpfile_list)
        self.insert_upload(self.file_todo_list)
        vod_info = []
        for file in self.uploaded_list:
            info = {}
            info['uid'] = file.uid
            info['vod_url'] = file.vod_url
            info['status'] = 1
            vod_info.append(info)
        result = Resp.parse(code = RespCode.success, content = vod_info)
        print result
        return result


    # 填充file_list信息
    def update_file_list(self, tmpfile_list):
        uploading_uids = [x.uid for x in self.uploading_list]
        uploaded_uids = [x.uid for x in self.uploaded_list]
        self.file_todo_list = []
        target_base = self.config.filesystem.dir
        for tmpfile in tmpfile_list:
            if tmpfile.uid in uploading_uids or tmpfile.uid in uploaded_uids:
                continue
            path, file_name = os.path.split(tmpfile.source_dir)
            target_dir = os.path.join(target_base, tmpfile.source_dir)
            vod_format = self.config.nginx.publish_url
            vod_url = vod_format.format(filename = tmpfile.source_dir)
            file = FileInfo(uid = tmpfile.uid, 
                            group_id = tmpfile.group_id,
                            base_dir = tmpfile.base_dir, 
                            source_dir = tmpfile.source_dir,
                            file_size = tmpfile.file_size,
                            target_dir = target_dir,
                            vod_url = vod_url
                            )
            self.file_todo_list.append(file)


    #获取当前uid_list中上传中或已上传的数据
    def get_publish_list(self, uid_list, status):
        sql = """
                select 
                    uid, group_id, base_dir, source_dir, target_dir, vod_url 
                from file_info
                where 
                    uid in ('{uid}')
                    and status = {status}
              """
        uid_tuple = tuple(eval(json.dumps(uid_list)))
        uid_args = "','".join(uid_tuple)
        sql = sql.format(uid = uid_args, status = status)
        records = self.db.query(sql)
        dbupload_list = []
        if records is not None:
            for r in records:
                vod = FileInfo(uid = r['uid'],
                               group_id = r['group_id'],
                               base_dir = r['base_dir'],
                               source_dir = r['source_dir'],
                               target_dir = r['target_dir'],
                               vod_url = r['vod_url'])
                dbupload_list.append(vod)
        return dbupload_list


    #获取上传队列
    def get_upload_list(self):
        sql = """
                select count(*) as count from file_info
                where status = 0 or status = 1
              """
        rowcount = self.db.get(sql)
        return rowcount['count']


    #插入上传队列
    def insert_upload(self, files):
        sql_get_orderid = "select ifnull(max(upload_order+1), 1) orderid from file_info"
        orderid = self.db.get(sql_get_orderid)['orderid']
        sql_format = """
                insert into 
                    file_info(uid, group_id, base_dir, source_dir, file_size, \
                                target_dir, vod_url, upload_order, status)
                values('%s', '%s', '%s', '%s', %d, '%s', '%s', \
                            (select a.maxid from 
                                (select ifnull(max(upload_order+1),1) maxid 
                                from file_info)a limit 1), 1)
              """ 

        sqls = []
        for file in files:
            sql = sql_format % (file.uid, file.group_id, file.base_dir, \
                        file.source_dir, file.file_size, file.target_dir, file.vod_url)
            self.db.execute(sql)
