# -*- coding:utf-8 -*-

import json
import torndb
import uuid

from util.respcode import Resp, Code, RespCode
from service.basehandler import BaseHandler
from service.fileinfo import FileInfo

class DegreeHandler(BaseHandler):
    def _post(self, params):
        client_ip = params['client_ip']
        access_time = params['access_time']
        source_dir = params['source_dir']

        sql = """
            insert into 
                file_degree('uid', 'source_dir', 'client_ip')
            values
                ('%s', '%s', '%s')
        """ % (uuid.uuid1(), source_dir, client_ip)
        self.db.execute(sql)
