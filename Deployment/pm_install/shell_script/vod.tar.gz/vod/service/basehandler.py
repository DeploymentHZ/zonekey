# -*- coding:utf-8 -*-

"""
override _get, _post, _put, _delete, instead of get, post, put, delete
so BaseHandler would log input and output message
But, override the latter when request need to be asynchronous
"""
import json
import logging

import tornado.escape
import torndb
from tornado.web import RequestHandler
from util.respcode import RespCode, Resp

class BaseHandler(RequestHandler):
    def __init__(self, application, request, **kwargs):
        RequestHandler.__init__(self, application, request, **kwargs)
        self.__define()
        self.config = application.config

    @property
    def db(self):
        return self.application.db

    """ use self.request.headers['X-Real-Ip] to get remote_ip
        after using load balancer or reverse proxy
    """
    @property
    def _remote_ip(self):
        return self.request.remote_ip

    def __define(self):
        self._default_success = Resp.parse(RespCode.success)
        self._not_supported_method = Resp.parse(RespCode.not_supported_method, failure='不支持的方法')

    def get(self):
        params = self.input(True)
        logging.info('method:%s request: %s' %('GET', params))
        result = self._get(params)
        logging.info('result:  %s' % result)
        self.write(result)

    def _get(self, params):
        return self._not_supported_method

    def post(self):
        params = self.input()
        logging.info('method:%s request: %s' %('POST', params))
        result = self._post(params)
        logging.info('result:  %s' % result)
        self.write(result)

    def _post(self,params): 
        return self._not_supported_method

    def put(self):
        params = self.input()
        logging.info('method:%s request: %s' %('PUT', params))
        result = self._put(params)
        logging.info('result:  %s' % result)
        self.write(result)

    def _put(self, params):
        return self._not_supported_method

    def delete(self):
        params = self.input()
        logging.info('method:%s request: %s' %('DELETE', params))
        result = self._put(params)
        logging.info('result:  %s' % result)
        self.write(result)
        
    def _delete(self, params):
        return self._not_supported_method

    def input(self, is_get = False):
        dict = None
        if is_get:
            keys = self.request.arguments.keys()
            if keys is not None and len(keys) > 0:
                dict = keys[0]
        else:
            dict = self.request.body
        
        if dict is None:
            return dict

        return json.loads(dict)
