-- create database and grant privilege
--  CREATE database IF NOT EXISTS vod;
--  grant all privileges on vod.* to 'vod'@'localhost' identified by 'vod';
--
-- init db
--  mysql --user=vod --password=vod --database=vod < initDB.sql

SET SESSION storage_engine = "InnoDB";
SET SESSION time_zone = "+8:00";
ALTER DATABASE CHARACTER SET "utf8";

DROP TABLE IF EXISTS file_info;
CREATE TABLE file_info (
    uid                 CHAR(32),
    group_id            TEXT,
    base_dir            TEXT,
    source_dir          TEXT,
    file_size           BIGINT DEFAULT 0,
    target_dir          TEXT,
    vod_url             TEXT,
    upload_order        INTEGER DEFAULT 1,
    status              INTEGER,
    lastupdatetime      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS file_degree;
CREATE TABLE file_degree (
    uid                 CHAR(32),
    source_dir          TEXT,
    client_ip           TEXT,
    access_time         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status              INTEGER DEFAULT 1,
    lastupdatetime      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
