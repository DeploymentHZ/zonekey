#-*- coding:utf-8 -*-

import json

class Code:
    SUCCESS = 0

class RespCode:
    success = (0, 'SUCCESS')
    not_supported_method = (101, 'NOT_SUPPORTED_METHOD')
    no_parameter = (102, 'NO_PARAMETER')
    invalid_parameter = (103, 'INVALID_PARAMETER')
    db_error = (110, 'DB_ERROR')
    invalid_status = (122, 'INVALID_STATUS')
    socket_error = (150, 'SOCKET_ERROR')
    unknown_error = (200, 'UNKNOWN_ERROR')

class Resp(object):
    @classmethod
    def parse(self, code = RespCode.success, content = None, failure = None):
        code, str = code
        resp = {}
        resp['response_code'] = code
        resp['response_string'] = str
        if failure is not None:
            resp['failure_reason'] = failure
        if content is not None:
            resp['content'] = content
        return json.dumps(resp)

    @classmethod
    def response_code(self, data):
        if 'response_code' not in data:
            return None
        return data['response_code']

    @classmethod
    def response_string(self, data):
        if 'response_string' not in data:
            return None
        return data['response_string']

    @classmethod
    def content(self, data):
        if 'content' not in data:
            return None
        return data['content']

    @classmethod
    def failure(self, data):
        if 'failure_reason' not in data:
            return None
        return data['failure_reason']
