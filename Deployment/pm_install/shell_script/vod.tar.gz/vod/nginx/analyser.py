#!/usr/bin/env python
#
# -*- coding:utf-8 -*-

import re
import time
import json
import urllib
import httplib

dir_path = '/opt/nginx_logs/'

def main():
    p = re.compile('(.*?)\s-\s\[(.*?)\]\s\"GET\s(.*?)\s.*?\"\s206', re.IGNORECASE)
    today = time.strftime('%Y%m%d', time.localtime(time.time()))
    file_path = dir_path + 'video' + today + '.log'
    file = open(file_path)
    for line in file:
        print line
        g = p.search(line)
        print g.group(1) # client_ip
        print g.group(2) # access_time
        print g.group(3) # source_dir

    file.close()

if __name__ == '__main__':
    main()
