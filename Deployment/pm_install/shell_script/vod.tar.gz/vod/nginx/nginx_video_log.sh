#!/bin/bash

log_name="video.log"
log_source_path="/usr/local/nginx/logs/"
log_dest_path="/opt/nginx_logs/"
pid_path="/usr/local/nginx/logs/nginx.pid"

if [ ! -f "$log_dest_path" ]; then
    mkdir -p "$log_dest_path"
fi
if [ ! -f "$log_source_path$log_name" ]; then
    touch "$log_source_path$log_name"
fi

mv ${log_source_path}${log_name} ${log_dest_path}"video"$(date -d now +%Y%m%d).log
kill -USR1 `cat ${pid_path}`
