#!/usr/bin/env python
#
# -*- coding:utf-8 -*-

import os
import logging
import logging.config
import ConfigParser

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import torndb
from tornado.options import define, options

from util.config import Config
from service.vodrequest import VodRequestHandler
from service.degree import DegreeHandler

CONF_FILE = 'conf/vod.conf'
define('port', default = 60010, help = 'run on the give port', type = int)

class App(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/vod/vodrequest", VodRequestHandler),
            (r"/vod/degree", DegreeHandler),
        ]
        tornado.web.Application.__init__(self, handlers)


def init_logging():
    cf = ConfigParser.ConfigParser()
    cf.read(Config.log.conf_path)
    cf.set('handler_fileHandler', 'args', "(%s, 'a')" % Config.log.file_path)
    cf.write(open(Config.log.conf_path, 'w'))

    logging.config.fileConfig(Config.log.conf_path, None, False)
    
def main():
    #load config
    Config.setup(CONF_FILE)

    options.parse_command_line()
    app = App()
    app.config = Config
    app.db = torndb.Connection(
        host=Config.db.mysql_host, database=Config.db.mysql_database,
        user=Config.db.mysql_user, password=Config.db.mysql_password)
    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()

if __name__ == '__main__':
    main()
