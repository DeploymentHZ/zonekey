# -*- coding:utf-8 -*-

import os

def remove_old(db):
    sql = "select * \
            from file_info \
            where status=2 \
            order by lastupdatetime limit 1"
    file = db.get(sql)
    try:
        folder = os.path.dirname(file['target_dir'])
        os.remove(file['target_dir'])
        dirlist = os.listdir(folder)
        if len(dirlist) == 0:
            print folder, 'is empty'
            os.rmdir(folder)
    except Exception, ex:
        print 'error remove', str(ex)
    sql = "update file_info set status=4 where uid='%s'" % file['uid']
    db.execute(sql)

def remove_lowrate(db):
    sql = """
    """
    file = db.get(sql)
    try:
        folder = os.path.dirname(file['target_dir'])
        os.remove(file['target_dir'])
        dirlist = os.listdir(folder)
        if len(dirlist) == 0:
            print folder, 'is empty'
            os.rmdir(folder)
    except Exception, ex:
        print 'error remove', str(ex)
    sql = "update file_info set status=4 where uid='%s'" % file['uid']
    db.execute(sql)
