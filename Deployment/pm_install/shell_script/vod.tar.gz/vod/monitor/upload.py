#!/usr/bin/env python
#
# coding:utf-8 -*-

import os, shutil
import ConfigParser
import time
import torndb
from os.path import join, getsize

import function
from config import Config

# status: success=2 not exist=3 other=10
CONF_FILE = 'monitor.conf'
remove_method

def get_file_list(db):
    sql = """
        select uid, group_id, base_dir, source_dir, file_size, 
            target_dir, vod_url, upload_order, status
        from file_info
        where status = 1
        order by upload_order
    """
    result = db.query(sql)
    return result

def update_file_list(db, file_list):
    print 'file_list is ', file_list
    for file in file_list:
        try:
            capacity = int(Config.nginx.capacity)
            curr_capacity = get_total_filesize(db)
            print 'current capacity', curr_capacity, 'left capacity is ', capacity - curr_capacity
            while(capacity - curr_capacity < file['file_size']):
                remove_method(db)
                curr_capacity = get_total_filesize(db)
            source_file = os.path.join(file['base_dir'], file['source_dir'])
            if not os.path.exists(source_file):
                update_db(db, file['uid'],file['upload_order'], 3)
            else:
                target_path, file_name = os.path.split(file['target_dir'])
                if not os.path.isdir(target_path):
                    os.makedirs(target_path)
                shutil.copy(source_file, file['target_dir'])
                update_db(db, file['uid'], file['upload_order'], 2)
        except Exception, ex:
            print str(ex)
            update_db(db, file['uid'], file['upload_order'], 10)

def update_db(db, uid, upload_order, status):
    sql = "update file_info set status=%d where uid='%s' and upload_order=%d" % (status, uid, upload_order)
    db.execute(sql)

def get_total_filesize(db):
    sql = "select ifnull(sum(file_size),0) total_size from file_info where status=2"
    size = db.get(sql)
    return int(size['total_size'])

def main():
    Config.setup(CONF_FILE)
    db = torndb.Connection(
        host=Config.db.mysql_host, database=Config.db.mysql_database,
        user=Config.db.mysql_user, password=Config.db.mysql_password)

    if Config.function.remove is 'old':
        remove_method = function.remove_old
    elif Config.function.remove is 'lowrate':
        remove_method = function.remove_lowrate
    else:
        remove_method = None

    while(remove_method):
        file_list = get_file_list(db)
        update_file_list(db, file_list)

        time.sleep(int(Config.store.interval))

if __name__ == '__main__':
    main()
