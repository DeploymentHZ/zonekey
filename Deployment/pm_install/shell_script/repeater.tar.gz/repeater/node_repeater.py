#!/usr/bin/env python
#
# -*- coding:utf-8 -*- 

import logging, logging.config, ConfigParser
import threading, subprocess
import json
import uuid
import os, signal

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
from tornado.options import define, options

import service
from util.Config import Config
from util.DbManager import DbManager
from util.ManagerHandler import ManagerHandler
from service.RtmpServer import RtmpServer
from service.CrtmpServer import CrtmpServerHandler
from service.PushStreamInfo import PushStreamInfoHandler
from service.PullStreamInfo import PullStreamInfoHandler
from service.NodeHeartBeat import NodeHeartBeatHandler

CONF_FILE = 'conf/node.conf'
define('port', default = 50010, help = 'run on the given port', type = int)

class App(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/repeater/node/nodeheartbeat", NodeHeartBeatHandler),
            (r"/repeater/node/crtmpserver", CrtmpServerHandler),
            (r"/repeater/node/pushstreaminfo", PushStreamInfoHandler),
            (r"/repeater/node/pullstreaminfo", PullStreamInfoHandler),
        ]
        super(App, self).__init__(handlers)

        self.uid = '%s' % uuid.uuid1()
        self.host = service.get_local_ip(Config.local.nic_name)
        self.port = options.port
        self.setup_crtmpserver()

    def setup_crtmpserver(self):
        self.server_list = []
        masters = json.loads(Config.crtmpserver.master)
        for master in masters:
            server = RtmpServer(uid = master['uid'],
                                node_server_uid = self.uid,
                                host = self.host,
                                bin_path = master['bin_path'], 
                                conf_path = master['conf_path'],
                                rtmp_port = int(master['rtmp_port']), 
                                load = int(master['max_load'])
                                )
            self.server_list.append(server)

def setup_config():
    cf = ConfigParser.ConfigParser()
    cf.read(CONF_FILE)
    new_masters = []
    masters = eval(cf.get('crtmpserver', 'master'))
    for server in masters:
        node = json.loads(json.dumps(server))
        node['uid'] = '%s' % uuid.uuid1()
        node['bin_path'] = '%s' % os.path.abspath(node['bin_path'])
        node['conf_path'] = '%s' % os.path.abspath(node['conf_path'])
        new_masters.append(node)
    cf.set('crtmpserver', 'master', '\n' + json.dumps(new_masters, sort_keys = True, indent = 4))
    cf.write(open(CONF_FILE, 'w'))

    Config.setup(CONF_FILE)

def init_logging():
    cf = ConfigParser.ConfigParser()
    cf.read(Config.log.conf_path)
    cf.set('handler_fileHandler', 'args', "(%s, 'a')" % Config.log.file_path)
    cf.write(open(Config.log.conf_path, 'w'))

    logging.config.fileConfig(Config.log.conf_path, None, False)

def sig_handler(sig, frame):
    ManagerHandler.logger.info("node_repeater is shutting down...")
    proc_master.kill()
    http_server.stop()
    io_loop = tornado.ioloop.IOLoop.instance()
    io_loop.stop()

def start_master():
    cmd_master = ['./master/master.py', '%s' % Config.master.tcp_port, '%s' % Config.master.udp_port, '%s' % options.port]
    global proc_master
    proc_master = subprocess.Popen(cmd_master)

def main():
    #load Config
    setup_config()

    #init log
    init_logging()

    #manager handler
    ManagerHandler.logger = logging.getLogger('file.logger')
    ManagerHandler.config = Config

    #set signal handler
    signal.signal(signal.SIGTERM, sig_handler)
    signal.signal(signal.SIGINT, sig_handler)

    #parse command
    tornado.options.parse_command_line()

    app = App()
    global http_server
    http_server = tornado.httpserver.HTTPServer(app)

    #register
    service.register_node(app)
    service.register_rtmpserver(app)

    #start master
    th_master = threading.Thread(target = start_master)
    th_master.start()

    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()

if __name__ == '__main__':
    main()
