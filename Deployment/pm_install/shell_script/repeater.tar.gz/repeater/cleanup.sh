#!/bin/bash

#cleaup file like below:
# *.pyc
# /log
# /log_node

for i in `find ./ -type f -name "*.pyc"` ; do rm -rf $i; done
rm -rf ./log;
rm -rf ./log_node;
