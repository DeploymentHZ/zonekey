# -*- coding:utf-8 -*-

import ConfigParser

class Config:
    @classmethod
    def setup(cls, path):
        cf = ConfigParser.ConfigParser()
        cf.read(path)
        for section in cf.sections():
            log_sector = Sector()
            for option in cf.options(section):
                option_value = cf.get(section, option)
                log_sector.register(option, option_value)
            Config.register(section, log_sector)

    @classmethod
    def register(cls, sector, sec_value):
        setattr(Config, sector, sec_value)

class Sector:
    def register(self, option, opt_value):
        setattr(self, option, opt_value) 
