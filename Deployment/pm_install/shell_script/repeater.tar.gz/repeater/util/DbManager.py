# -*- coding:utf-8 -*-

import sqlite3
import json
from ManagerHandler import ManagerHandler
from RespCode import Resp, RespCode

class DbManager(object):
    def __init__(self):
        try:
            self._con = sqlite3.connect(ManagerHandler.db)
        except sqlite3.Error, ex:
            ManagerHandler.logger.error("Connect to sqlite3 '%s' failed, Exception is '%s'" % (ManagerHandler.db, str(ex)))  

    def __del__(self):
        if self._con != None:
            self._con.close()

    def executeQuery(self, sql):
        if self._con == None:
            reason = 'db connection CLOSED'
            return self.make_failure(failure = reason)

        ManagerHandler.logger.info('execute query: %s' % sql)
        _cur = self._con.cursor()
        _cur.execute(sql)
        ret = _cur.fetchall()
        _cur.close()

        return self.make_success(ret)

    def executeScalar(self, sql):
        if self._con == None:
            reason = 'db connection CLOSED'
            return self.make_failure(failure = reason)

        ManagerHandler.logger.info('execute scalar: %s' % sql)
        _cur = self._con.cursor()
        _cur.execute(sql)
        ret = _cur.fetchone()
        _cur.close()

        return self.make_success(ret)


    def executeNonQuery(self, sql):
        if self._con == None:
            reason = 'db connection CLOSED'
            return self.make_failure(reason)

        _cur = self._con.cursor()
        try:
            ManagerHandler.logger.info('execute nonquery: %s' % sql)
            _cur.execute(sql)
            self._con.commit()
            rc = _cur.rowcount
            _cur.close()
            return self.make_success()
        except Exception,ex:
            self._con.rollback()
            ManagerHandler.logger.error("rollback transaction, Exception is '%s'" % str(ex))
            _cur.close()
            return self.make_failure(failure = str(ex))

    def executeNonQueryBatch(self, sqls):
        if self._con == None:
            reason = 'db connection CLOSED'
            return self.make_failure(failure = reason)

        _cur = self._con.cursor()
        ManagerHandler.logger.info('BEGIN execute trans')
        for sql in sqls:
            try:
                ManagerHandler.logger.info('execute nonquery: %s' % sql)
                _cur.execute(sql)
            except Exception, ex:
                self._con.rollback()
                ManagerHandler.logger.error("rollback transaction, Exception is '%s'" % str(ex))
                _cur.close()
                return self.make_failure(failure = str(ex))

        _cur.close()
        self._con.commit()
        ManagerHandler.logger.info('END execute trans')
        return self.make_success()

    def make_failure(self, code = RespCode.db_error, failure = None):
        respCode = code
        result = Resp.parse(respCode, failure = failure)
        return json.loads(result)

    def make_success(self, content = None):
        result= Resp.parse(RespCode.success, content = content)
        return json.loads(result)
