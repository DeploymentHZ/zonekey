# -*- coding:utf-8 -*- 

class ManagerHandler(object):
    logger = None
    config = None
    db = None
