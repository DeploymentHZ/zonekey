#-*- coding:utf-8 -*-

import time

def time():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
