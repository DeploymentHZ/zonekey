import socket
class TcpClient:
    def __init__(self, port, host = 'localhost'):
        self.ADDR = (host, port)
    def send(self, msg):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(self.ADDR)
            sock.send(msg)
            return True
        except Exception, ex:
            failure= str(ex)
            return failure
