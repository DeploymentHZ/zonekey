sqlite3 data.db < init.sql
