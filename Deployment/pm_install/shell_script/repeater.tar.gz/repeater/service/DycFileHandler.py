#-*- coding:utf-8 -*-

import os
import logging
import time

class DycFileHandler(logging.FileHandler):
    def __init__(self, path, mode):
        filename = time.strftime('%Y-%m-%d', time.localtime(time.time()))
        if os.path.exists(path)==False:
            os.mkdir(path)
        path = path + ("/%s.log" % filename)
        super(DycFileHandler, self).__init__(path, mode)
