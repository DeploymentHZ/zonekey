#-*- coding:utf-8 -*-

import os
import json
from util.RespCode import RespCode, Resp
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager
from util.TcpClient import TcpClient

from BaseHandler import BaseHandler

class CrtmpServerHandler(BaseHandler):
    def _post(self, params):
        uid = params['uid'].decode()

        #communicate with master.py using socket
        servers = [x for x in self.application.server_list if x.uid == uid]
        if len(servers) != 1:
            failure = "can not find crtmpserver instance with uid '%s'" % uid
            result = Resp.parse(RespCode.db_error, failure = failure)
            return result
        server = servers[0]
        msg = {}
        msg["from"] = "node"
        msg["cmd"] = "start"
        info = {}
        info['bin_path'] = server.bin_path
        info['conf_path'] = server.conf_path
        info["rtmp_port"] = server.rtmp_port
        info['uid'] = server.uid
        msg["info"] = info
        msg = json.dumps(msg)
        masterClient = TcpClient(int(ManagerHandler.config.master.tcp_port))
        result = masterClient.send(msg)
        if result:
            return self._default_success
        else:
            result = Resp.parse(RespCode.socket_timeout, failure = result)
            return result

    def _put(self, params):
        uid = params['uid'].decode()
        servers = [x for x in self.application.server_list if x.uid == uid]
        if len(servers) != 1:
            failure = "can not find crtmpserver instance with uid '%s'" % uid
            result = Resp.parse(RespCode.db_error, failure = failure)
            return result
        server = servers[0]
        msg = {}
        msg["from"] = "node"
        msg["cmd"] = "stop"
        info = {}
        info['uid'] = server.uid
        msg["info"] = info
        msg = json.dumps(msg)
        masterClient = TcpClient(int(ManagerHandler.config.master.tcp_port))
        result = masterClient.send(msg)
        if result:
            return self._default_success
        else:
            result = Resp.parse(RespCode.socket_timeout, failure = result)
            return result
