# -*- coding:utf-8 -*-

import json

from BaseHandler import BaseHandler
from tornado.web import asynchronous, gen
from util.HttpClient import HttpClient
from util.RespCode import Code, RespCode, Resp
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager

class RtmpServerHandler(BaseHandler):
    def _get(self, params):
        sql = """
                select
                    t1.uid, t1.node_server_uid, t1.bin_path, t1.conf_path,
                    t1.rtmp_port, t1.status, t1.max_load, t1.current_load
                from 
                    stream_server t1, node_server t2
                where t1.node_server_uid = t2.uid
              """
        where_condition = None
        print int(params['status'])
        if int(params['status']) != 3:
            where_condition = ' and t1.status = %d' % int(params['status']) 
        if where_condition != None:
            sql += where_condition
        db_mgr = DbManager()
        result = db_mgr.executeQuery(sql)
        content = []
        for r in result['content']:
            tmp = {}
            tmp['uid'] = r[0]
            tmp['node_server_uid'] = r[1]
            tmp['bin_path'] = r[2]
            tmp['conf_path'] = r[3]
            tmp['host'] = r[3]
            tmp['port'] = r[4]
            tmp['rtmp_port'] = r[5]
            tmp['status'] = int(r[6])
            tmp['max_load'] = int(r[7])
            tmp['current_load'] = int(r[8])
            content.append(tmp)

        result = Resp.parse(RespCode.success, content = content)
        return result

    # 启动crtmpserver
    def _post(self, params):
        db_mgr = DbManager()
        #check stream_server uid if valid
        sql = """
                select node_server_uid, status from stream_server
                where uid is '%s' 
            """ % params['uid']
        result = db_mgr.executeScalar(sql)
        if result['response_code'] != Code.SUCCESS:
            return result
        if Resp.content(result) is None:
            failure = "no stream_server with uid '%s' found" % params['uid']
            result = Resp.parse(RespCode.invalid_parameter, failure = failure)
            return result

        #check stream_server status
        server_uid, status = result['content']
        if status != 0:
            failure = "stream_server status error"
            result = Resp.parse(RespCode.invalid_parameter, failure = failure)
            return result

        # start server
        node_url = 'http://%s:%d/repeater/node/crtmpserver'
        sql ="""
            select host, port from node_server 
            where uid is '%s'
            """ % server_uid
        result = db_mgr.executeScalar(sql)
        if result['response_code'] != Code.SUCCESS:
            return result
        host, port = result['content']
        node_url = node_url % (host, port)
        http_client = HttpClient(node_url)
        result = http_client.post(params)
        if result['response_code'] != Code.SUCCESS:
            return result
        return self.add_stream_server(db_mgr, params['uid'])

    # 停止crtmpserver
    def _put(self, params):
        db_mgr = DbManager()
        # check stream_server uid 
        sql = """
                select node_server_uid, status from stream_server
                where uid is '%s'
            """ % params['uid']
        result = db_mgr.executeScalar(sql)
        if result['response_code'] != Code.SUCCESS:
            return result
        if Resp.content(result) is None:
            failure = "no stream_server with uid '%s' found" % params['uid']
            result = Resp.parse(RespCode.invalid_parameter, failure = failure)
            return result

        # check stream_server status
        server_uid, status = result['content']
        if status != 1:
            failure = "stream_server status error"
            result = Resp.parse(RespCode.invalid_parameter, failure = failure)
            return result

        # stop server
        node_url = 'http://%s:%d/repeater/node/crtmpserver'
        sql = """
            select host, port from node_server
            where uid is '%s'
            """ % server_uid
        result = db_mgr.executeScalar(sql)
        if result['response_code'] != Code.SUCCESS:
            return result
        host, port = result['content']
        node_url = node_url % (host, port)
        http_client = HttpClient(node_url)
        result = http_client.put(params)
        if result['response_code'] != Code.SUCCESS:
            return result
        return self.update_stream_server(db_mgr, params['uid'])

    def add_stream_server(self, db_mgr, uid):
        update_sql = """
                        update stream_server
                        set
                            status = 1
                        where uid = '%s'
                    """ % uid
        return db_mgr.executeNonQuery(update_sql)

    def update_stream_server(self, db_mgr, uid):
        update_sql = """
                        update stream_server
                        set
                            status = 0
                        where uid = '%s'
                     """ % uid
        return db_mgr.executeNonQuery(update_sql)

class RtmpServer:
    def __init__(self, uid, node_server_uid, host, bin_path, conf_path, rtmp_port, load, current_load = 0):
        self.uid = uid
        self.node_server_uid = node_server_uid
        self.host = host
        self.bin_path = bin_path
        self.conf_path = conf_path
        self.rtmp_port = rtmp_port
        self.max_load = load
        self.current_load = current_load
