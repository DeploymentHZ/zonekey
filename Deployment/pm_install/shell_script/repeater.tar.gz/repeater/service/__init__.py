import socket
import struct
import fcntl

import os
import json

from util.ManagerHandler import ManagerHandler
from util.HttpClient import HttpClient
from util.RespCode import Resp, Code, RespCode

def get_local_ip(ifname = 'eth0'):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    inet = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
    ret = socket.inet_ntoa(inet[20:24])
    return ret

def register_node(app):
    """insert into node_server 
    """
    url = ManagerHandler.config.repeater.path + '/repeater/center/dbnodeserver'
    node_server = {}
    node_server['uid'] = app.uid
    node_server['host'] = app.host
    node_server['port'] = app.port
    http_client = HttpClient(url)
    result = http_client.post(node_server)

def register_rtmpserver(app):
    """insert into stream_server
    """
    masters = ManagerHandler.config.crtmpserver.master
    url = ManagerHandler.config.repeater.path + '/repeater/center/dbstreamserver'
    masters = []
    for server in app.server_list:
       stream_server = {}
       stream_server['uid'] = server.uid
       stream_server['node_server_uid'] = server.node_server_uid
       stream_server['bin_path'] = server.bin_path
       stream_server['conf_path'] = server.conf_path
       stream_server['host'] = server.host
       stream_server['rtmp_port'] = server.rtmp_port
       stream_server['max_load'] = server.max_load
       masters.append(stream_server)

    http_client = HttpClient(url)
    response = http_client.post(masters)
    if response['response_code'] != Code.SUCCESS:
        return False
    return True
