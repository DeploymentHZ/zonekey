# -*- coding:utf-8 -*-

from BaseHandler import BaseHandler
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager
import service.DbRtmpApply

class DbPullStreamInfoHandler(BaseHandler):
    def _post(self, params):
        rtmp_apply_uid = service.DbRtmpApply.get_rtmp_apply_uid(params['uid'], 1)
        sql_add_rtmp_pull_info = """
            insert into rtmp_pull_info
                (rtmp_apply_uid, stream_server_uid, pull_host, pull_port, status)
            values
                ('%s', '%s', 'localhost', 0, 1)
        """ % (rtmp_apply_uid, params['stream_server_uid'])
        db_mgr = DbManager()
        result = db_mgr.executeNonQuery(sql_add_rtmp_pull_info)
        return result

    def _put(self, params):
        rtmp_apply_uid = service.DbRtmpApply.get_rtmp_apply_uid(params['uid'], 2)
        sql_update_rtmp_pull_info = \
            "update rtmp_pull_info set status = 2 where rtmp_apply_uid = '%s'" \
            % rtmp_apply_uid
        db_mgr = DbManager()
        result = db_mgr.executeNonQuery(sql_update_rtmp_pull_info)
        return result
