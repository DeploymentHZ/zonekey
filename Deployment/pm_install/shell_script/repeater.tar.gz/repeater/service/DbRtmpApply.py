# -*- coding:utf-8 -*-

from util.DbManager import DbManager
from util.RespCode import Resp, Code, RespCode

def get_rtmp_apply_uid(stream_uid, status):
    db_mgr = DbManager()
    sql = """
        select uid
        from rtmp_apply
        where stream_uid = '{stream_uid}'
        and status = {status}
    """
    sql = sql.format(stream_uid = stream_uid, status=status)
    result = db_mgr.executeScalar(sql)
    result = Resp.content(result)
    content = '0'
    if result:
        content = result[0]
    return content

