# -*- coding:utf-8 -*-

from BaseHandler import BaseHandler
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager
import service.DbRtmpApply

class DbPushStreamInfoHandler(BaseHandler):
    def _get(self, params):
        sql_select_rtmp_push_info = """
            select 
            from rtmp_push_info
            where group_id={}
        """

    def _post(self, params):
        rtmp_apply_uid = service.DbRtmpApply.get_rtmp_apply_uid(params['uid'], 1)
        sql_add_rtmp_push_info = """
            insert into rtmp_push_info
                (rtmp_apply_uid, stream_server_uid, push_host, push_port, status) 
            values
                ('%s', '%s', 'localhost', 0, 1)
        """ % (rtmp_apply_uid, params['stream_server_uid'])

        sql_update_rtmp_apply = """
            update rtmp_apply set status = 2
            where uid = '%s'
        """ % rtmp_apply_uid

        sql_update_server_load = """
            update stream_server set current_load = current_load + 1
            where uid = '%s'
        """ % params['stream_server_uid']

        sqls = []
        sqls.append(sql_add_rtmp_push_info)
        sqls.append(sql_update_rtmp_apply)
        sqls.append(sql_update_server_load)
        db_mgr = DbManager()
        result = db_mgr.executeNonQueryBatch(sqls)
        #result = db_mgr.executeNonQuery(sql_add_rtmp_push_info)
        return result

    def _put(self, params):
        rtmp_apply_uid = service.DbRtmpApply.get_rtmp_apply_uid(params['uid'], 2)
        sql_update_rtmp_push_info = "update rtmp_push_info set status = 2 \
                                     where rtmp_apply_uid = '%s'" % rtmp_apply_uid
        sql_update_rtmp_apply = "update rtmp_apply set status = 3 \
                                 where uid = '%s'" % rtmp_apply_uid
        sql_update_server_load = """
            update stream_server set current_load = current_load - 1
            where uid = '%s'
        """ % params['stream_server_uid']

        sqls = []
        sqls.append(sql_update_rtmp_push_info)
        sqls.append(sql_update_rtmp_apply)
        sqls.append(sql_update_server_load)
        db_mgr = DbManager()
        result = db_mgr.executeNonQueryBatch(sqls)
        #result = db_mgr.executeNonQuery(sql_update_rtmp_push_info)
        return result
