#-*- coding:utf-8 -*-

from BaseHandler import BaseHandler
from util.RespCode import Resp, Code, RespCode
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager

class StreamInfoHandler(BaseHandler):
    def _get(self, params):
        type = params['type']

        result = None
        if type.lower() == 'push':
            result = self.get_push_info(params)
        elif type.lower() == 'pull':
            result = self.get_pull_info(params)
        else:
            ManagerHandler.logger.Error('wrong type')
            failure = "get wrong stream type"
            result = Resp.parse(RespCode.invalid_parameter, failure = failure)
            return result

        if result is None:
            result = Resp.parse(RespCode.db_error, failure = 'db error')
        else:
            result = Resp.parse(RespCode.success, content = result)

        return result


    def get_push_info(self, params):
        group_id = params['group_id']
        sql = """
            select t1.group_id, t1.stream_uid, t1.stream_server_uid, t1.publish_url,
                   t2.status
            from rtmp_apply t1, rtmp_push_info t2
            where t1.uid = t2.rtmp_apply_uid
                and t1.group_id = '%s'
                and t2.status = 1
        """ % group_id
        db_mgr = DbManager()
        result = db_mgr.executeQuery(sql)
        if result['response_code'] != Code.SUCCESS or \
            Resp.content(result) is None:
            return None

        push_list = []
        for record in Resp.content(result):
            push = {}
            push['group_id'] = record[0]
            push['stream_uid'] = record[1]
            push['stream_server_uid'] = record[2]
            push['publish_url'] = record[3]
            push['status'] = int(record[4])
            push_list.append(push)
        return push_list

    def get_pull_info(self, params):
        return None
