# -*- coding:utf-8 -*-

import time
from util.RespCode import Resp, Code, RespCode
from util.HttpClient import HttpClient

REPEATE = 3
class HeartBeatManager(object):
    def __init__(self, db_mgr):
        HeartBeatManager.is_running = False
        self.db_mgr = db_mgr

    @classmethod
    def set_is_running(cls, flag):
        HeartBeatManager.is_running = flag

    def start_pulse(self, interval = 5):
        HeartBeatManager.is_running = True
        self.interval = interval
        while(HeartBeatManager.is_running):
            self.pulse()
            time.sleep(interval)

    """
     pulse step:
     1.get node state
     2.if node offline:
          set node and servers in node offline
     3.if node online:
          send servers in db to node 
          and update server state
    """
    def pulse(self):
        sql = "select uid, host, port from node_config where status = 1"
        nodes = self.db_mgr.executeQuery(sql)
        if Resp.content(nodes) is None:
            return
        for node in Resp.content(nodes):
            node_state = self.pulse_node(node)
            if node_state == False:
                self.update_offline(node)

    # get node state, online True, offline False
    # cycle for REPEATE times if first time failes
    def pulse_node(self, node):
        is_live = self.pulse_node_once(node)
        if is_live == False:
            for round in range(1, REPEATE):
                is_live = self.pulse_node_once(node)
                if is_live == True:
                    break
                time.sleep(self.interval)

        return is_live

    # get node pulse once
    def pulse_node_once(self, node):
        uid, host, port = node
        request_url = "http://%s:%d/repeater/node/nodeheartbeat" % (host, port)
        http_client = HttpClient(request_url)
        params = {}
        params['uid'] = uid
        response = http_client.get(params)
        print response
        if response['response_code'] != Code.SUCCESS:
            return False
        return True

    def update_offline(self, node):
        uid, host, port = node
        
        #update node state
        sql = "update node_config set status = 2 where uid = '%s'" % uid
        self.db_mgr.executeNonQuery(sql)

        #update crtmpserver state
        sql = "update stream_server set status = 2 where node_uid ='%s'" % uid
        self.db_mgr.executeNonQuery(sql)
