# -*- coding:utf-8 -*-

from util.HttpClient import HttpClient
from BaseHandler import BaseHandler
from util.ManagerHandler import ManagerHandler
from util.RespCode import RespCode, Resp

class PullStreamInfoHandler(BaseHandler):
    def _post(self, params):
        url = "%s/repeater/center/dbpullstreaminfo" % ManagerHandler.config.repeater.path
        http_client = HttpClient(url)
        result = http_client.post(params)
        return result

    def _put(self, params):
        url = "%s/repeater/center/dbpullstreaminfo" % ManagerHandler.config.repeater.path
        http_client = HttpClient(url)
        result = http_client.put(params)
        return result
