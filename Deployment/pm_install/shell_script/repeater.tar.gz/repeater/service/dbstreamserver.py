#-*- coding:utf-8 -*-

from BaseHandler import BaseHandler
from util.RespCode import RespCode, Resp, Code
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager
from util.HttpClient import HttpClient

from tornado.options import options

class DbStreamServerHandler(BaseHandler):
    def _get(self, params):
        sql = """
                select 
                    uid, node_server_uid, rtmp_port, status, max_load, current_load
                from 
                    stream_server
              """
        db_mgr = DbManager()
        result = db_mgr.executeQuery(sql)
        if result['response_code'] != Code.SUCCESS:
            return result
        content = []
        for record in result['content']:
            tmp = {}
            tmp['uid'] = record[0]
            tmp['node_uid'] = record[1]
            tmp['rtmp_port'] = record[2]
            tmp['status'] = record[3]
            tmp['max_load'] = record[4]
            tmp['current_load'] = record[5]
            content.append(tmp)
        result['content'] = content
        return result

    def _post(self, params):
        sqls = []
        for master in params:
            sql = """
                insert into stream_server
                    (uid, node_server_uid, bin_path, conf_path, host, rtmp_port, status, max_load, current_load) 
                values 
                    ('%s', '%s', '%s', '%s', '%s', %d, 0, %d, 0)
                """ % ( master['uid'], 
                        master['node_server_uid'], 
                        master['bin_path'], 
                        master['conf_path'], 
                        master['host'], 
                        master['rtmp_port'], 
                        master['max_load'] )
            sqls.append(sql)
        db_mgr = DbManager()
        result = db_mgr.executeNonQueryBatch(sqls)
        self.start_server(params)
        return result

    def start_server(self, params):
        url_start_server = "http://127.0.0.1:%d/repeater/rtmpserver" % options.port
        http_client = HttpClient(url_start_server)
        for server in params:
            uid = server['uid']
            msg = {}
            msg['uid'] = uid
            http_client.post(msg)
