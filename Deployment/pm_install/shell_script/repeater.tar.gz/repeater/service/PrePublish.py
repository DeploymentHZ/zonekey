# -*- coding:utf-8 -*-

import json
import uuid
from BaseHandler import BaseHandler
from util.RespCode import Code, RespCode, Resp
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager

ISAPPLYING = 1
ISPUBLISHING = 2

class ApplyRecord(object):
    def __init__(self, stream_uid, group_id, stream_server_uid, publish_url):
        self.stream_uid = stream_uid
        self.group_id = group_id
        self.stream_server_uid = stream_server_uid
        self.publish_url = publish_url

class PrePublishBatchHandler(BaseHandler):
    """
        1.查询正在传入uids中是否有正在直播的流，若存在，返回失败及直播流信息
        2.删除rtmp_apply中status=1的流
        3.判断stream_server是否可以直播
        4.插入rtmp_apply中新记录
    """
    def _post(self, params):
        db_mgr = DbManager()
        group_id = params['group_id']
        uids = params['uids']
        uid_list = [x['uid'] for x in params['uids']]
        invalid_records = self.get_invalid_records(db_mgr, uid_list, group_id)
        if len(invalid_records) > 0:
            content = [x.__dict__ for x in invalid_records]
            failure = 'have some publishing records'
            result = Resp.parse(RespCode.invalid_status, content = content, failure = failure)
            return result

        self.delete_rtmp_apply(db_mgr, uid_list, group_id)

        node = self.get_node_info(db_mgr, len(uid_list))
        if node is None:
            failure = 'all servers are shutdown or full, please check'
            result = Resp.parse(RespCode.no_valid_servers, failure = failure)
            return result

        stream_server_uid, host, rtmp_port = node
        content = []
        sqls = []
        sql_format = """    
                        insert into rtmp_apply(
                            uid, stream_uid, group_id, stream_name,stream_server_uid, publish_url, status)
                        values
                            ('%s', '%s', '%s', '%s', '%s', '%s', %d)
                    """
        for stream_uid in uid_list:
            publish_url = 'rtmp://{host}:{port}/zonekey/{uid}'
            publish = {}
            publish['uid'] = stream_uid
            publish['rtmp_repeater'] = publish_url.format(host = host, port = rtmp_port, uid = stream_uid)
            content.append(publish)
            sql = sql_format % (uuid.uuid1(), stream_uid, group_id, stream_uid, stream_server_uid, publish['rtmp_repeater'], 1)
            sqls.append(sql)
        db_mgr.executeNonQueryBatch(sqls)
        result = Resp.parse(RespCode.success, content = content)
        return result

    def get_invalid_records(self, db_mgr, uid_list, group_id):
        sql = """
                select stream_uid, group_id, stream_server_uid, publish_url 
                from rtmp_apply
                where
                    group_id = "{group_id}"
                    and stream_uid in ('{stream_uid}')
                    and status = {status}
              """
        uid_tuple = tuple(eval(json.dumps(uid_list)))
        uid_args = "','".join(uid_tuple)
        sql = sql.format(group_id = group_id, stream_uid = uid_args, status = ISPUBLISHING)
        records = db_mgr.executeQuery(sql)
        record_list = []
        if Resp.content(records) is not None:
            for r in Resp.content(records):
                apply_record = ApplyRecord(r[0], r[1], r[2], r[3])
                record_list.append(apply_record)
        return record_list

    def delete_rtmp_apply(self, db_mgr, uid_list, group_id):
        sql = """
                delete from rtmp_apply 
                where 
                    group_id = "{group_id}"
                    and stream_uid in ('{stream_uid}')
                    and status = {status}
            """
        uid_tuple = tuple(eval(json.dumps(uid_list)))
        uid_args = "','".join(uid_tuple)
        sql = sql.format(group_id = group_id, stream_uid = uid_args, status = ISAPPLYING)
        db_mgr.executeNonQuery(sql)

    def get_node_info(self, db_mgr, num):
        sql = """
                select t1.uid, t1.host, t2.rtmp_port
                from node_server t1, stream_server t2
                where t2.status = 1 and t2.max_load - t2.current_load > %d
                order by t2.max_load - t2.current_load desc
              """ % num
        node = db_mgr.executeScalar(sql)
        if Resp.content(node) is None:
            return None
        return node['content']
