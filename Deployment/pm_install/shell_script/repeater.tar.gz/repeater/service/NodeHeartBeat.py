# -*- coding:utf-8 -*- 

from BaseHandler import BaseHandler
from util.RespCode import Resp, Code, RespCode

class NodeHeartBeatHandler(BaseHandler):
    def _get(self, params):
        uid = params['uid']
        print self.application.uid, uid
        if self.application.uid != uid:
            result = Resp.parse(RespCode.node_offline, failure = 'uid not matched')
            return result

        return self._default_success
