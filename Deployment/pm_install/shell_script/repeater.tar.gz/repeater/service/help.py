# -*- coding:utf-8 -*-

from BaseHandler import BaseHandler

class HelpHandler(BaseHandler):
    def get(self):
        self.render('help.html')
