#-*- coding:utf-8 -*-

import json
from BaseHandler import BaseHandler
from util.RespCode import RespCode, Resp, Code
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager

class DbNodeServerHandler(BaseHandler):
    def _get(self, params):
        sql = """
                select uid, host, port, status
                from node_server
             """
        db_mgr = DbManager()
        result = db_mgr.executeQuery(sql)
        if result['response_code'] != Code.SUCCESS:
            return result
        content = []
        for record in result['content']:
            tmp = {}
            tmp['uid'] = record[0]
            tmp['host'] = record[1]
            tmp['port'] = record[2]
            tmp['status'] = record[3]
            content.append(tmp)
        result['content'] = content
        return result


    def _post(self, params):
        sql ="""
            insert into node_server
                (uid, host, port, status) 
            values
                ('%s','%s', %d, 1)
            """ % (params['uid'], params['host'], int(params['port']))
        db_mgr = DbManager()
        result = db_mgr.executeNonQuery(sql)
        return result
