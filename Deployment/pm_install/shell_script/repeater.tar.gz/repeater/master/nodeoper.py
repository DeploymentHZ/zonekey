#coding:utf-8

import os
import json
import threading
import subprocess

class NodeOper:
    def __init__(self, cmd, udp_port):
        self.cmd = cmd
        self.udp_port = udp_port

    def oper(self, msg):
        if self.cmd == 'start':
            bin_path = msg['bin_path']
            conf_path = msg['conf_path']
            port = msg['rtmp_port']
            uid = msg['uid']
            th_crtmpserver = threading.Thread(target = self.start_crtmpserver, \
                        args=(bin_path, conf_path, uid))
            th_crtmpserver.start()
        elif self.cmd == 'stop':
            uid = msg['uid']
            self.stop_manager(uid)

    def start_crtmpserver(self, bin_path, conf_path, uid):
        start_cmd = [bin_path, 'master-udpport=%d' % self.udp_port, '%s' % uid, conf_path]
        proc_server = subprocess.Popen(start_cmd)
        NodeOperManager.pid_dict[uid] = proc_server
        print NodeOperManager.pid_dict

    def stop_manager(self, uid):
        if uid not in NodeOperManager.pid_dict:
            print uid,'not in NodeOperManager'
            return
        proc = NodeOperManager.pid_dict[uid]
        proc.kill()
        del(NodeOperManager.pid_dict[uid])
        print NodeOperManager

class NodeOperManager:
    pid_dict = {}
