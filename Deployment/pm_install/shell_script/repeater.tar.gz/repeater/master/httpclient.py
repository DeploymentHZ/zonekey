#-*- coding:utf-8 -*-

import json
from tornado.httpclient import *
from RespCode import Resp, RespCode

REQ_TIMEOUT = 1
class HttpClient:
    def __init__(self, url, timeout = REQ_TIMEOUT):
        self.http_client = HTTPClient()
        self.url = url
        self.timeout = timeout

    def get(self, dict = None):
        result = self.request('GET', dict)
        return result
        
    def post(self, dict = None):
        result = self.request('POST', dict)
        return result

    def put(self, dict = None):
        result = self.request('PUT', dict)
        return result

    def delete(self, dict = None):
        result = self.request('DELETE', dict)
        return result

    def request(self, method, dict = None):
        try:
            req = HTTPRequest(self.url, request_timeout = self.timeout, method = method, body = json.dumps(dict))
            resp = self.http_client.fetch(req)
            return json.loads(resp.body)
        except HTTPError as e:
            failure = str(e)
            result = Resp.parse(RespCode.socket_error, failure = failure)
            return json.loads(result)
        except Exception, ex:
            failure = str(ex)
            result = Resp.parse(RespCode.unknown_error, failure = failure)
            return json.loads(result)
