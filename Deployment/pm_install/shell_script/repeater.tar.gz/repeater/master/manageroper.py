from httpclient import HttpClient

class ManagerOper:
    def __init__(self, cmd, node_port):
        self.cmd = cmd
        self.node_port = node_port

    def oper(self, msg):
        if self.cmd == 'push_add':
            self.send_to_node_pushstreaminfo('POST', msg)
        elif self.cmd == 'push_sub':
            self.send_to_node_pushstreaminfo('PUT', msg)
        elif self.cmd == 'pull_add':
            self.send_to_node_pullstreaminfo('POST', msg)
        elif self.cmd == 'pull_sub':
            self.send_to_node_pullstreaminfo('PUT', msg)

    def send_to_node_pushstreaminfo(self, method, msg):
        url_pushstreaminfo = "http://127.0.0.1:%d/repeater/node/pushstreaminfo" % self.node_port
        params = {}
        params['uid'] = msg['stream_name']
        params['stream_server_uid'] = msg['uid']
        http_client =  HttpClient(url_pushstreaminfo)
        result = http_client.request(method, params)
        return result

    def send_to_node_pullstreaminfo(self, method, msg):
        url_pullstreaminfo = "http://127.0.0.1:%d/repeater/node/pullstreaminfo" % self.node_port
        params = {}
        params['uid'] = msg['stream_name']
        params['stream_server_uid'] = msg['uid']
        http_client = HttpClient(url_pullstreaminfo)
        result = http_client.request(method, params)
        return result
