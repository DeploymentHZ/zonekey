#!/usr/bin/env python
#
# -*- coding:utf-8 -*-

import sys
import json
import subprocess
import threading
import os
import signal

from SocketServer import ThreadingTCPServer, ThreadingUDPServer,\
         StreamRequestHandler as SRHTCP, DatagramRequestHandler as SRHUDP

from nodeoper import NodeOper, NodeOperManager
from manageroper import ManagerOper

NODE_PORT = 0
TCP_PORT = 0
UDP_PORT = 0
class AsyncTCPRequestHandler(SRHTCP):
    def handle(self):
        msg = self.rfile.readline()
        msg = json.loads(msg)
        print('tcp message: ', msg)
        if msg['from'] == 'node':
            node_oper = NodeOper(msg['cmd'], UDP_PORT)
            node_oper.oper(msg['info'])
        else:
            print('tcp got no exit')

class AsyncUDPRequestHandler(SRHUDP):
    def handle(self):
        msg = self.rfile.readline()
        msg = json.loads(msg)
        print('udp message: ', msg)
        if msg['from'] == 'crtmpserver':
            manager_oper = ManagerOper(msg['cmd'], NODE_PORT)
            manager_oper.oper(msg)
        else:
            print('udp got no exit')

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print 'error params with length %d' % len(sys.argv)
    else:
        NODE_PORT = int(sys.argv[3])
        TCP_PORT = int(sys.argv[1])
        UDP_PORT = int(sys.argv[2])

        print('master start... ', NODE_PORT)
        print('master TCP_PORT is ', TCP_PORT)
        print('master UDP_PORT is ', UDP_PORT)

        host = 'localhost'
        addr = (host, TCP_PORT)    
        #start tcp listener
        tcp_server = ThreadingTCPServer(addr, AsyncTCPRequestHandler)
        th_tcp = threading.Thread(target = tcp_server.serve_forever)
        th_tcp.start()

        addr = (host, UDP_PORT)
        #start udp listener
        udp_server = ThreadingUDPServer(addr, AsyncUDPRequestHandler)
        th_udp = threading.Thread(target = udp_server.serve_forever)
        th_udp.start()
