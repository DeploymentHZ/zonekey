-- init:
-- SQLITE3 data.db < init.sql

DROP TABLE node_server;
CREATE TABLE node_server(
    uid                     char(32) NOT NULL primary key,
    host                    varchar(15),
    port                    integer,
    status                  integer,
    lastupdatetime          timestamp default(datetime(current_timestamp, 'localtime'))
);

DROP TABLE rtmp_apply;
CREATE TABLE rtmp_apply(
    uid                     char(32) NOT NULL primary key,
    stream_uid              text NOT NULL,
    group_id                text NOT NULL,
    stream_name             text,              --default the same as stream_uid
    stream_server_uid       char(32),
    publish_url             text,
    apply_time              timestamp default(datetime(current_timestamp, 'localtime')),
    status                  integer,            --1已申请 2正在发布 3已结束 4无效
    lastupdatetime          timestamp default(datetime(current_timestamp, 'localtime'))
);

DROP TABLE rtmp_pull_info;
CREATE TABLE rtmp_pull_info(
    rtmp_apply_uid          char(32),
    stream_server_uid       char(32),
    pull_host               varchar(15),
    pull_port               integer,
    start_time              timestamp default(datetime(current_timestamp, 'localtime')),
    status                  integer,            --1使用中 2已结束
    lastupdatetime          timestamp default(datetime(current_timestamp, 'localtime'))
);

DROP TABLE rtmp_push_info;
CREATE TABLE rtmp_push_info(
    rtmp_apply_uid          char(32),
    stream_server_uid       char(32),
    push_host               varchar(15),
    push_port               integer,
    start_time              timestamp default(datetime(current_timestamp, 'localtime')),
    status                  integer,            --1发布中 2已结束 
    lastupdatetime          timestamp default(datetime(current_timestamp, 'localtime'))
);

DROP TABLE stream_server;
CREATE TABLE stream_server(
    uid                     char(32) NOT NULL primary key,
    node_server_uid         char(32),
    bin_path                text,
    conf_path               text,
    host                    varchar(15),
    rtmp_port               integer,
    status                  integer,
    max_load                integer,
    current_load            integer,
    lastupdatetime          timestamp default(datetime(current_timestamp, 'localtime'))
);
