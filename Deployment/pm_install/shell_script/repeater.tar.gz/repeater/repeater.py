#!/usr/bin/env python
#
# -*- coding:utf-8 -*- 

import logging
import logging.config
import ConfigParser
import threading
import signal,time

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
from tornado.options import define, options

from util.Config import Config
from util.ManagerHandler import ManagerHandler
from util.DbManager import DbManager

from service.dbnodeserver import DbNodeServerHandler
from service.DbPushStreamInfo import DbPushStreamInfoHandler
from service.DbPullStreamInfo import DbPullStreamInfoHandler
from service.dbstreamserver import DbStreamServerHandler
from service.RtmpServer import RtmpServerHandler
from service.PrePublish import PrePublishBatchHandler
from service.StreamInfo import StreamInfoHandler
from service.HeartBeat import HeartBeatManager
from service.help import HelpHandler

CONF_FILE = 'conf/repeater.conf'
MAX_WAIT_SECONDS = 6
define('port', default = 50001, help = 'run on the given port', type = int)

class Server(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/repeater/help", HelpHandler),

            (r"/repeater/center/dbnodeserver", DbNodeServerHandler),
            (r"/repeater/center/dbstreamserver", DbStreamServerHandler),
            (r"/repeater/center/dbpushstreaminfo", DbPushStreamInfoHandler),    
            (r"/repeater/center/dbpullstreaminfo", DbPullStreamInfoHandler),

            (r"/repeater/dbnodeserver", DbNodeServerHandler),
            (r"/repeater/rtmpserver", RtmpServerHandler),
            (r"/repeater/prepublishbatch", PrePublishBatchHandler),
            (r"/repeater/streaminfo", StreamInfoHandler),
        ]

        tornado.web.Application.__init__(self, handlers)

def init_logging():
    cf = ConfigParser.ConfigParser()
    cf.read(Config.log.conf_path)
    cf.set('handler_fileHandler', 'args', "(%s,'a')" % Config.log.file_path)
    cf.write(open(Config.log.conf_path, 'w'))

    logging.config.fileConfig(Config.log.conf_path, None, False)

def start_heartbeat():
    db_mgr = DbManager()
    heartbeat_mgr = HeartBeatManager(db_mgr)
    heartbeat_mgr.start_pulse()

def sig_handler(sig, frame):
    ManagerHandler.logger.info('Stopping http server')
    HeartBeatManager.set_is_running(False)
    http_server.stop()

    ManagerHandler.logger.info('repeater will shutdown in %s seconds...',MAX_WAIT_SECONDS)
    io_loop = tornado.ioloop.IOLoop.instance()
    deadline = time.time() + MAX_WAIT_SECONDS

    def stop_loop():
        now = time.time()
        if now < deadline and (io_loop._callbacks or io_loop._timeouts):
            io_loop.add_timeout(now+1, stop_loop)
        else:
            io_loop.stop()
            ManagerHandler.logger.info('web_server shutdown')

    stop_loop()

def main():
    #load Config
    Config.setup(CONF_FILE)
    
    #init log
    init_logging()

    #manager handler
    ManagerHandler.logger = logging.getLogger('file.logger')
    ManagerHandler.config = Config
    ManagerHandler.db = Config.db.file_path

    #start heartbeat
    th_heartbeat = threading.Thread(target = start_heartbeat)
    #th_heartbeat.start()

    #set signal handler
    signal.signal(signal.SIGTERM, sig_handler)
    signal.signal(signal.SIGINT, sig_handler)

    options.parse_command_line()

    global http_server
    http_server = tornado.httpserver.HTTPServer(Server(), xheaders=True)
    http_server.listen(options.port)
    print('starting repeater...')
    tornado.ioloop.IOLoop.instance().start()

if __name__ == '__main__':
    main()
