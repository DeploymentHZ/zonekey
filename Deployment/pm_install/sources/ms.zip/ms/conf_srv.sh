#!/bin/bash

APP="/home/data/upload/update/conf_srv.py"

pgrep conf_srv.py
if [ "$?" -eq "0" ]
then
	echo 'running'
	exit
else
	$APP &
fi

