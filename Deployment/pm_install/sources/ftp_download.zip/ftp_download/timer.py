import  data
import time
import download_manual

def timer (db):
    i=data.forword(db)
    startime=i[0]
    endtime=i[1]
    if ((time.strftime('%H%M') > startime) and (time.strftime('%H%M') < endtime)) or (startime == None and endtime == None):
     download_manual.main_download(db,'auto')
     print 'upload is over------------------'


