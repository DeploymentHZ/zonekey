#!/usr/bin/python2.6
import main

if __name__== '__main__':
    main.main()
