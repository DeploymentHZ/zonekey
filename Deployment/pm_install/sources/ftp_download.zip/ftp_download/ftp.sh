
#!/bin/bash
cmd=pgrep
pproc=ftpdownload.py

if [ -n "`$cmd $pproc`" ]
    then 
	sleep 2
    else
	python /home/ftp_download/ftpdownload.py  >/dev/null 2>&1


fi
