import data
import delete
import shutil

def timeing(db):
    for i in data.timing(db):
        day=i[-1]
        day=str(day)
        if day >=data.del_days(db):
            ip=i[3]
            path=i[0]
            id=i[2]
            try:
                delete.del_mamaul(ip,path)
                data.del_status(id,db)
            except Exception as e:
                e = str(e)
                print e,'-------delete ',ip,"/",path,"is failed"
                if e.find("550")==0:
                   	data.del_status(id,db)				
    delResource(db)
    
#delete resource
def delResource(db):
    for i in data.get_resource(db):
    	  floder = i[1]
    	  path = i[0]+floder
    	  try:
    	      print path
    	      shutil.rmtree(path)
    	  except Exception as e:
    	      print e,'------the file is not exists'	
          data.del_resource(db,floder)
