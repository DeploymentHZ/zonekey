import data
import compare
import download_manual
import timer
import os
import ConfigParser
import del_timeing
import time
import MySQLdb

class mysql:
    def __init__(self):
        config = ConfigParser.ConfigParser()
        config.read("/home/ftp_download/config.ini")
        
        self.host = config.get("dbconf","host")
        self.port = config.get("dbconf","port")
        self.user = config.get("dbconf","user")
        self.pwd = config.get("dbconf","password")
        self.db_name = config.get("dbconf","db_name")
        self.resource_path = config.get("global","resource_path")
        self.freeSpace = config.get("global","freeSpace")
        
        self.conn = MySQLdb.connect(host=self.host,user=self.user,passwd=self.pwd,db=self.db_name,port=int(self.port))
        self.cur = self.conn.cursor()
        
    def select_data(self,sql):
    	   self.cur.execute(sql)
    	   return self.cur.fetchall()
    	   
    def select_one_data(self,sql):
    	   self.cur.execute(sql)
    	   return self.cur.fetchone()
    	   
    def update_data(self,sql):
         self.cur.execute(sql)
         self.conn.commit()
         
    def close(self):
        self.conn.close() 
        
def main():
    db = mysql()
    del_timeing.delResource(db)
    hddinfo = os.statvfs(db.resource_path)
    free = hddinfo.f_frsize * hddinfo.f_bavail/(1024*1024*1024)
    try:
        if(free<int(db.freeSpace)):
            print 'There is not enough space,the space is',free
            return
        if data.manual_count(db) <> 0:
            download_manual.main_download(db,'manual')
        timer.timer(db)
        print '-------------ready delete video file------------'
        del_timeing.timeing(db)
        print '-------------delete video file end------------'
    finally:
        db.close()     	
