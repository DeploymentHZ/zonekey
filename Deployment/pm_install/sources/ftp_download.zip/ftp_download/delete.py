from ftplib  import  FTP

def del_mamaul(ip,path):
    try:
        ftp=FTP()
        ftp.connect(ip,'21',3)
        ftp.login('','')
        ftp.cwd(path)
        dir=ftp.nlst()
        for i in dir:
          ftp.delete(i)
        ftp.cwd('..')
        ftp.rmd(path)
    finally:
        ftp.close()
