import os
wget='wget -c  -r -nH --dont-remove-listing -t 1 -np %s -P %s'%('ftp://192.168.13.123/20150207003Z105/','/home')
os.system(wget)
