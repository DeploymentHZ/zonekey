import data
import delete
import os
import os.path

def compare(path):
    localFile = os.listdir(path)
    listingPath=path+'.listing'
    listingFile = open(listingPath,'r').readlines()
    localFile.remove(".listing")
    for fileInfo in listingFile:
        fileInfo=fileInfo.strip()
        fileInfo=fileInfo.split(' ')
        fileName=fileInfo[-1]
        fileSize=fileInfo[-2]
        filePath = path+fileName
        size = os.path.getsize(filePath)
        fileSize = int(fileSize)
        if size!=fileSize:
            if size>fileSize:
               os.system("rm -rf %s"%(path))
            return False
    return True   
     
def manaul_compare (db,datas):
    id=datas[-4]
    ip=datas[-3]
    del1=datas[-1]
    resourcefloder = datas[0]
    floder = datas[3]
    del_path=datas[-2]
    path=datas[-2]
    path=db.resource_path+path+'/'
    listing=path+'.listing'
    if os.path.exists(path):
        text_count=len(open(listing,'r').readlines())
        file_count=os.listdir(path)
        file_count = len(file_count)-1
        if text_count == file_count:
            if compare(path):
                if del1 == 'Y':
                    delete.del_mamaul(ip,del_path)
                    data.del_status(id,db)
                data.status(id,db)
                data.add_resource(resourcefloder,floder,id,db)
            else:
                print 'to be continued......',ip
