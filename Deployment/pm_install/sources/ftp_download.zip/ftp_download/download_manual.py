import data
import os
import compare

def download (datas,db):
    ip=str(datas[0])
    wget='wget -c -q -r -nH --limit-rate=10240k --dont-remove-listing -t 1 -T 1 -np %s -P %s'%(ip,db.resource_path)
    try:
     data.starttime(datas[-4],db)
     flag = os.system(wget)
     if flag==0:
      compare.manaul_compare(db,datas)
     else:
     	print 'connection failed:',ip       
    except Exception as e:
     print e,ip
     
def main_download (db,flag):
    list_data = data.manual_data(db,flag)    
    for i in list_data:
        download(i,db)
