import MySQLdb
import datetime
import time
import os
import os.path

def manual_count(db):
    sql=db.select_data("SELECT count(*) FROM zonekey_curriculum a,zonekey_device b WHERE  a.deleteflag=0 and b.deleteflag=0 and uploadstatus<>2 AND a.areaid=b.areaid AND b.typeid='1' AND upload_is_manual='Y'")
    for i in sql:
        i=i[0]
        return i

def manual_data(db,method):
    sqlStr = "SELECT a.areaid,uploadtime,resourcefloder,uploadstatus,uploadbegin,uploadend,ip,a.id,upload_is_delete \
			FROM zonekey_curriculum a,zonekey_device b \
			WHERE a.deleteflag=0 and b.deleteflag=0 and a.areaid=b.areaid AND b.typeid='1'  AND uploadstatus<>2  "
    if(method == 'manual'):
      sqlStr += "AND upload_is_manual='Y'"
    else:
      sqlStr += "AND upload_is_manual='N' AND isupload='1' and  sysDate()>concat(date,' ',endtime) and date<=date_format(sysDate(),'%Y-%m-%d') and a.record='1' and datediff(date_format(sysDate(),'%Y-%m-%d'),date)<5"
    sqlStr+=" group by b.ip,a.resourcefloder;"
    sql=db.select_data(sqlStr)
    list_data=[]
    for i in sql:
        if i[2] != None:
            list=[]
            path='ftp://'+i[-3]+'/'+i[2]
            id=i[-2]
            list.append(path)
            list.append(id)
            list.append(i[-3])
            list.append(i[2])
            list.append(i[-1])
            list_data.append(list)
    return list_data

def forword (db):
    list_data=db.select_one_data("SELECT starttime,endtime FROM zonekey_resource_upload_strategy WHERE areaid=0 AND deleteflag=0")
    return list_data

def starttime(id,db):
    starttime= time.strftime("%Y-%m-%d %H:%M:%S")
    starttime=str(starttime)
    sql=db.update_data("update zonekey_curriculum set uploadstatus=\'1\', uploadbegin=\'%s\' where id=\'%s\' "%(starttime,id))

def status(id,db):
    endtime= time.strftime("%Y-%m-%d %H:%M:%S")
    endtime=str(endtime)
    update=db.update_data("update zonekey_curriculum set uploadstatus=\'2\',uploadend=\'%s\' where id=\'%s\'"%(endtime,id))

def del_status(id,db):
    update=db.update_data("update zonekey_curriculum set uploaddeletestatus=\'2\' where id=\'%s\'"%(id))

def timing(db):
    sql=db.select_data("select date,resourcefloder,uploaddeletestatus,a.id,ip from zonekey_curriculum a,zonekey_device b where  a.areaid=b.areaid and upload_is_delete=\'N\' and uploaddeletestatus=\'0\' and uploadstatus=\'2\' ")
    list_data=[]
    for i  in sql:
        list=[]
        date0=i[0]
        date1=datetime.datetime.now()
        date1=str(date1)
        date1=datetime.datetime.strptime(date1,"%Y-%m-%d %H:%M:%S.%f").date()
        date2=date1-date0
        path=i[1]
        delete_status=i[2]
        id=i[3]
        ip=i[4]
        list.append(path)
        list.append(delete_status)
        list.append(id)
        list.append(ip)
        list.append(date2)
        list_data.append(list)
    return list_data

def del_days(db):
    sql=db.select_data("select days FROM zonekey_resource_remove_strategy")
    sql=sql[0][0]
    return  sql
    
#insert to zonekey_resource
def add_resource(path,floder,id,db):
    fileurl=db.resource_path+floder
    files=getFiles(fileurl)
    for file in files:	
     name = file[0]
     size = file[1]
     db.update_data("insert into zonekey_resource(fileurl,source,floder,resourcename,name,size,curriculumid,createdate)values(\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',sysDate())"%(db.resource_path,path,floder,floder,name,size,id))
       
#travelsal files
def getFiles(floder):
    files = []
    if os.path.exists(floder):
        list=[]
        for file in os.listdir(floder):
            if file != '.listing':
                data = []
                data.append(file)
                size=os.path.getsize(os.path.join(floder,file))
                data.append(size)
                list.append(data)
    return list 
    
#delete resource
def del_resource(db,floder):
    #db.update_data("update zonekey_resource set deleteflag='1' where floder=\'%s\'"%(floder))
	db.update_data("delete from zonekey_resource where floder=\'%s\'"%(floder))

def get_resource(db): 	
    return db.select_data("select fileurl,floder file from zonekey_resource where deleteflag='2' group by floder")	
