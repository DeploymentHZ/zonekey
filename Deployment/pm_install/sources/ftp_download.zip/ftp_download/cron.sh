#!/bin/bash

mysql=`rpm -qa|grep MySQL-python|wc -l`
if [$mysql ==0];then
   yum install MySQL-python 
fi

count=`crontab -l |grep /home/ftp_download/ftp.sh|grep -v "grep"|wc -l`
if [ $count == 0 ];then
   echo "*/10 * * * * /home/ftp_download/ftp.sh"  >> /var/spool/cron/root
fi
   
